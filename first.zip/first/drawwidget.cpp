#include "drawwidget.h"
#include<QMouseEvent>
#include<QPainter>
namespace {
const QColor pointColor(240,100,22);
const QColor borderColor(Qt::gray);
const QColor backgroundColor(Qt::green);
const int gridStep = 40;
}
DrawWidget::DrawWidget(QWidget *parent)
    : QWidget{parent}
{


}
void  DrawWidjet::mousePressEvent(QPaintEvent *event){
    if(event->button()!==Qt::LeftButtton){return;}

    QPointF Pos = event->locallPos();
    m_points.append(Pos)
}

    void DrawWidjet::paintEvent(QPaintEvent  *event){
        QPainter painter(this);
        painter.fillRect(rectt(),backgroundColor);
        painter.setPen(QPen(borderColor, 2));
        for(int x = gridStep; x<width();x+=gridStep){
            painter.drawLine(x,0,x,height());
        }
        for(int y = gridStep; y<height();y+=gridStep){
            painter.drawLine(0,y,width(),y);
        }

        for (int i=0; i < m_points.size(); i++){
            painter.drawEllipse(m_point[i],20,20);
        }
    }



