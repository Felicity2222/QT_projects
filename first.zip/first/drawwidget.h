#ifndef DRAWWIDGET_H
#define DRAWWIDGET_H

#include <QWidget>

class DrawWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DrawWidget(QWidget *parent = nullptr);

signals:


protected:
    void paintEvent(QPaintEvent  *event) override;
    void mousePressEvent(QPaintEvent *event) override;
private:
    QVector<QPointF> m_points;
    QString resText;


};

#endif // DRAWWIDGET_H
